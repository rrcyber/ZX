﻿ZXTERNAL - 2026-09-10 build
=====================================
zx1.exe SHA-256: 870E0931A49991B9C9AE525CC4243573C12FE2CB5FD922D5418C21AB34A7CAA0

If Windows SmartScreen or your antivirus warns about zx1.exe,
that is expected for a tool that reads game memory. Add the
folder as an antivirus exclusion if features do not work.


﻿ZXTERNAL - 2026-09-15 build
=====================================
zx1.exe SHA-256: BBC544AC10B4773EC47A79D755E2850B01D0E71E40A6884AF9248841E7AE7E62

If Windows SmartScreen or your antivirus warns about zx1.exe,
that is expected for a tool that reads game memory. Add the
folder as an antivirus exclusion if features do not work.


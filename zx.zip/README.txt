ZXTERNAL - 2026-10-04 build
=====================================
zx1.exe SHA-256: AE463DBD7CDD19AEEE7167133E15E64C031DA70DEB2F14ECC3776299904E4C23
Targets Roblox: version-02c37bc51a384b8f

Run ZXTERNAL.bat - it checks GitHub for a newer build first, then
starts zx1.exe.

If Windows SmartScreen or your antivirus warns about zx1.exe, that is
expected for a tool that reads game memory. Add this folder as an
antivirus exclusion if features do not work.

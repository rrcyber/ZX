ZXTERNAL - 2026-10-16 build
=====================================
zx1.exe SHA-256: 22E6D59BB0F2E131D1E6453A25338D5697F8E87575ABA09D41000307F4BCC102
Targets Roblox: version-11f155f3450f4c8e

Run ZXTERNAL.bat - it checks GitHub for a newer build first, then
starts zx1.exe.

If Windows SmartScreen or your antivirus warns about zx1.exe, that is
expected for a tool that reads game memory. Add this folder as an
antivirus exclusion if features do not work.

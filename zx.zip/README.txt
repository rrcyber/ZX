ZXTERNAL - 2026-09-23 build
=====================================
zx1.exe SHA-256: 0682A3EC7DF9E3BE562D96EA533A4B4A8DDF35BADEF3BB5FDE469209C7FA690F
Targets Roblox: version-2366ba214ec740ca

Run ZXTERNAL.bat - it checks GitHub for a newer build first, then
starts zx1.exe.

If Windows SmartScreen or your antivirus warns about zx1.exe, that is
expected for a tool that reads game memory. Add this folder as an
antivirus exclusion if features do not work.

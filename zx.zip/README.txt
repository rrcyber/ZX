ZXTERNAL - 2026-10-14 build
=====================================
zx1.exe SHA-256: 1B25CB3131A3E94C64A7AF61009DC3E33BA2E5D5D68073BE954FD03FA0509942
Targets Roblox: version-7a0c6d10fcb34a2c

Run ZXTERNAL.bat - it checks GitHub for a newer build first, then
starts zx1.exe.

If Windows SmartScreen or your antivirus warns about zx1.exe, that is
expected for a tool that reads game memory. Add this folder as an
antivirus exclusion if features do not work.

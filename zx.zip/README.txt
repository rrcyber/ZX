﻿ZXTERNAL - 2026-09-08 build
=====================================
zx1.exe SHA-256: C1E70B7CD91AE411EA273D91B58BEF3F2C7CD28D05FC9353C4716717383C9813

If Windows SmartScreen or your antivirus warns about zx1.exe,
that is expected for a tool that reads game memory. Add the
folder as an antivirus exclusion if features do not work.


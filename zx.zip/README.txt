ZXTERNAL - 2026-11-07 build
=====================================
zx1.exe SHA-256: 63324A5B3A67971B767A465120E26B87DA32CB529281CFAB05381DDB4A263008
Targets Roblox: version-f0ea5da9412f4e35

Run ZXTERNAL.bat - it checks GitHub for a newer build first, then
starts zx1.exe.

If Windows SmartScreen or your antivirus warns about zx1.exe, that is
expected for a tool that reads game memory. Add this folder as an
antivirus exclusion if features do not work.

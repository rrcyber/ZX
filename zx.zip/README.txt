ZXTERNAL - 2026-10-29 build
=====================================
zx1.exe SHA-256: 9C8CAC24C267AAA9897B36107CAEC00752D386ACAF5402AB02AE2674DF03A71C
Targets Roblox: version-5a21b87bbc2641cf

Run ZXTERNAL.bat - it checks GitHub for a newer build first, then
starts zx1.exe.

If Windows SmartScreen or your antivirus warns about zx1.exe, that is
expected for a tool that reads game memory. Add this folder as an
antivirus exclusion if features do not work.

ZXTERNAL - 2026-10-09 build
=====================================
zx1.exe SHA-256: 69EBBD3DB1D401F88B8667A629B7116AC1F7D851774921E64F9C8C1140FADE06
Targets Roblox: version-cec3ad5889b447cf

Run ZXTERNAL.bat - it checks GitHub for a newer build first, then
starts zx1.exe.

If Windows SmartScreen or your antivirus warns about zx1.exe, that is
expected for a tool that reads game memory. Add this folder as an
antivirus exclusion if features do not work.

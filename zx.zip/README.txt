ZXTERNAL - 2026-11-11 build
=====================================
zx1.exe SHA-256: E6FC9F7426D92105E09CD1E44D43FE3143561CB2DD90EC4C8B54A46B6C53D94A
Targets Roblox: version-4ea8e85481e34f46

Run ZXTERNAL.bat - it checks GitHub for a newer build first, then
starts zx1.exe.

If Windows SmartScreen or your antivirus warns about zx1.exe, that is
expected for a tool that reads game memory. Add this folder as an
antivirus exclusion if features do not work.

ZXTERNAL - 2026-10-23 build
=====================================
zx1.exe SHA-256: 307768AE075BC4EC2EA2714312990D216FF4A3E63A654DA3C17D3B65CD7A803A
Targets Roblox: version-9ac8595712b447a7

Run ZXTERNAL.bat - it checks GitHub for a newer build first, then
starts zx1.exe.

If Windows SmartScreen or your antivirus warns about zx1.exe, that is
expected for a tool that reads game memory. Add this folder as an
antivirus exclusion if features do not work.

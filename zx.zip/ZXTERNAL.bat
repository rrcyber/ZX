@echo off
title ZXTERNAL
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0zxternal_updater.ps1"

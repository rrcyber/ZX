# zxternal_updater.ps1 - ZXTERNAL bootstrapper
# Checks the GitHub release zip against this folder, downloads + replaces
# everything when the online build is newer, then launches zx1.exe.
# Distribution: keep ZXTERNAL.bat + this file next to the install (both are
# shipped inside zx.zip too). ASCII only on purpose - no unicode tricks.

$ErrorActionPreference = 'Stop'

$banner = @'
 ____  _  _  ____  ____  ____  __ _   __   __
(__  )( \/ )(_  _)(  __)(  _ \(  ( \ / _\ (  )
 / _/  )  (   )(   ) _)  )   //    //    \/ (_/\
(____)(_/\_) (__) (____)(__\_)\_)__)\_/\_/\____/
'@

Write-Host ""
Write-Host $banner -ForegroundColor Cyan
Write-Host ""
Write-Host "  site: https://zxternal.netlify.app" -ForegroundColor DarkGray
Write-Host ""

$here     = Split-Path -Parent $MyInvocation.MyCommand.Path
$localExe = Join-Path $here 'zx1.exe'
$zipUrl   = 'https://github.com/rrcyber/ZX/raw/refs/heads/main/zx.zip'

function Pause-Exit([string]$msg) {
    Write-Host $msg -ForegroundColor Red
    Read-Host "Press Enter to close" | Out-Null
    exit 1
}

# --- version check -------------------------------------------------------
$updateAvailable = $false
try {
    $head = Invoke-WebRequest -Uri $zipUrl -Method Head -UseBasicParsing -TimeoutSec 20
    $remoteStamp = [DateTime]::MinValue
    $lm = $head.Headers['Last-Modified']
    if ($lm -is [array]) { $lm = $lm[0] }
    if ($lm) { $remoteStamp = [DateTime]$lm }
    $localStamp = [DateTime]::MinValue
    if (Test-Path $localExe) { $localStamp = (Get-Item $localExe).LastWriteTime }

    if (-not (Test-Path $localExe)) {
        $updateAvailable = $true
        Write-Host "  no local install found - downloading..." -ForegroundColor Yellow
    } elseif ($remoteStamp -gt $localStamp.AddSeconds(5)) {
        $updateAvailable = $true
        Write-Host "  update available - downloading new build..." -ForegroundColor Yellow
    } else {
        Write-Host "  up to date." -ForegroundColor Green
    }
} catch {
    if (Test-Path $localExe) {
        Write-Host "  could not reach GitHub - starting local build." -ForegroundColor Yellow
    } else {
        Pause-Exit "  cannot reach GitHub and no local install exists. Check internet."
    }
}

# --- download + replace --------------------------------------------------
if ($updateAvailable) {
    $tmpZip = Join-Path $env:TEMP 'zxternal_update.zip'
    try {
        Invoke-WebRequest -Uri $zipUrl -OutFile $tmpZip -UseBasicParsing
    } catch {
        Pause-Exit ("  download failed: " + $_.Exception.Message)
    }
    if ((Get-Item $tmpZip).Length -lt 1MB) {
        Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue
        Pause-Exit "  downloaded file is too small - GitHub may be rate limiting. Try again later."
    }

    # kill a running client so the files can be replaced
    Get-Process -Name 'zx1' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 600

    try {
        Expand-Archive -Path $tmpZip -DestinationPath $here -Force
    } catch {
        Pause-Exit ("  extract failed: " + $_.Exception.Message)
    }
    Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue
    Write-Host "  installed." -ForegroundColor Green
}

# --- launch --------------------------------------------------------------
if (-not (Test-Path $localExe)) { Pause-Exit "  zx1.exe not found after install." }

$running = Get-Process -Name 'zx1' -ErrorAction SilentlyContinue
if (-not $running) {
    Start-Process -FilePath $localExe -WorkingDirectory $here
    Write-Host "  ZXTERNAL started." -ForegroundColor Green
} else {
    Write-Host "  ZXTERNAL already running." -ForegroundColor Green
}
